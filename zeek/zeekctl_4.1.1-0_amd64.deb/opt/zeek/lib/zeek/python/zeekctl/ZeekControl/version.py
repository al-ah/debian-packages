#
# Settings that specify the version of ZeekControl
#

VERSION = "2.3.0-5"
ZEEKBASE = "/opt/zeek"
CFGFILE = "/opt/zeek/etc/zeekctl.cfg"
ZEEKSCRIPTDIR = "/opt/zeek/share/zeek"
LIBDIR = "/opt/zeek/lib"
LIBDIRINTERNAL = "/opt/zeek/lib/zeek/python"
