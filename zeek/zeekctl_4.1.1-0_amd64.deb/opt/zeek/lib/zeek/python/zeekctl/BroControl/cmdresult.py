#
# Legacy BroControl Plugin API. Importing it will abort.
#

import ZeekControl.cmdresult
CmdResult = ZeekControl.cmdresult.CmdResult
