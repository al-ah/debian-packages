#pragma once

#include <caf/config.hpp>

#define BROKER_ASSERT CAF_ASSERT
