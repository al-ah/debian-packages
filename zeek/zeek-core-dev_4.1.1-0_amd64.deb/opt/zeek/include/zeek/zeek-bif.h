#pragma once

// Headers to include by generated BiF code.
#include "zeek/Conn.h"
#include "zeek/NetVar.h"
#include "zeek/Event.h"
#include "zeek/Reporter.h"
#include "zeek/ID.h"
#include "zeek/EventRegistry.h"
#include "zeek/BifReturnVal.h"
