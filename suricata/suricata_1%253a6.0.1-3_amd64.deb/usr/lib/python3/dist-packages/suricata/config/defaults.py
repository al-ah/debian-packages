sysconfdir = "/etc/suricata/"
datarulesdir = "/usr/share/suricata/rules"
localstatedir = "/var/run/"
