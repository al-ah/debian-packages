from suricata.sc.suricatasc import *
