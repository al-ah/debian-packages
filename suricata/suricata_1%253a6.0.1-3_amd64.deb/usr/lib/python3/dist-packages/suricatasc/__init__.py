from suricata.sc import *
