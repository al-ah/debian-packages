# Version format:
# Release: 1.0.0
# Beta: 1.0.0b1
# Alpha: 1.0.0a1
# Development: 1.0.0dev0
# Release candidate: 1.0.0rc1
version = "1.2.1"
